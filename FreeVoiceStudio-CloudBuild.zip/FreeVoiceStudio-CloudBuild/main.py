import tkinter as tk
from tkinter import ttk, messagebox
import threading
import numpy as np
import sounddevice as sd
from pedalboard import Pedalboard, PitchShift, Reverb, Delay, Distortion, Chorus, Compressor, LowpassFilter, HighpassFilter

APP_NAME = "FreeVoice Studio"
SAMPLE_RATE = 48000
BLOCK_SIZE = 512

PRESETS = {
    "Normal": {},
    "Deep Voice": {"pitch": -7},
    "Higher Voice": {"pitch": 5},
    "Robot": {"robot": True, "distortion": 8},
    "Radio": {"radio": True, "distortion": 12},
    "Alien": {"pitch": 4, "robot": True, "reverb": 0.25},
    "Monster": {"pitch": -10, "distortion": 18, "reverb": 0.18},
    "Echo": {"echo": 0.35},
    "Cave": {"reverb": 0.65, "echo": 0.18},
    "Telephone": {"radio": True},
    "Chipmunk": {"pitch": 9},
    "Megaphone": {"radio": True, "distortion": 20},
    "Ghost": {"pitch": -3, "reverb": 0.55, "echo": 0.28},
    "Broadcast": {"compress": True, "radio": True},
}

class FreeVoiceStudio:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("760x610")
        self.root.minsize(700, 560)
        self.root.configure(bg="#15131d")
        self.stream = None
        self.running = False
        self.lock = threading.Lock()
        self.settings = {"pitch": 0, "robot": False, "radio": False,
                         "distortion": 0, "reverb": 0.0, "echo": 0.0,
                         "compress": False}
        self.build_ui()
        self.refresh_devices()
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TCombobox", fieldbackground="#252232", background="#302b40", foreground="white")
        style.configure("TButton", padding=8)
        style.configure("TLabel", background="#15131d", foreground="#eeeaf7")
        style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"), foreground="#c6a7ff")
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#aaa3b8")

        header = tk.Frame(self.root, bg="#15131d")
        header.pack(fill="x", padx=24, pady=(20, 8))
        ttk.Label(header, text="FREEVOICE STUDIO", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Real-time microphone effects • Free desktop project", style="Sub.TLabel").pack(anchor="w", pady=(3, 0))

        devices = tk.LabelFrame(self.root, text=" AUDIO DEVICES ", bg="#1e1b29", fg="#c6a7ff",
                                padx=12, pady=10, font=("Segoe UI", 9, "bold"))
        devices.pack(fill="x", padx=24, pady=12)
        tk.Label(devices, text="Microphone input", bg="#1e1b29", fg="white").grid(row=0, column=0, sticky="w")
        self.input_box = ttk.Combobox(devices, state="readonly", width=43)
        self.input_box.grid(row=1, column=0, padx=(0, 12), pady=6, sticky="ew")
        tk.Label(devices, text="Audio output", bg="#1e1b29", fg="white").grid(row=0, column=1, sticky="w")
        self.output_box = ttk.Combobox(devices, state="readonly", width=43)
        self.output_box.grid(row=1, column=1, pady=6, sticky="ew")
        devices.columnconfigure(0, weight=1)
        devices.columnconfigure(1, weight=1)
        tk.Button(devices, text="Refresh devices", command=self.refresh_devices,
                  bg="#383047", fg="white", relief="flat").grid(row=2, column=0, sticky="w", pady=(4, 0))

        controls = tk.LabelFrame(self.root, text=" VOICE LIBRARY ", bg="#1e1b29", fg="#c6a7ff",
                                 padx=14, pady=12, font=("Segoe UI", 9, "bold"))
        controls.pack(fill="both", expand=True, padx=24, pady=8)
        tk.Label(controls, text="Choose a preset", bg="#1e1b29", fg="white").pack(anchor="w")
        self.preset_box = ttk.Combobox(controls, state="readonly", values=list(PRESETS.keys()), width=35)
        self.preset_box.set("Normal")
        self.preset_box.pack(anchor="w", pady=(5, 12))
        self.preset_box.bind("<<ComboboxSelected>>", self.apply_preset)

        row = tk.Frame(controls, bg="#1e1b29")
        row.pack(fill="x")
        self.pitch_var = tk.DoubleVar(value=0)
        self.dist_var = tk.DoubleVar(value=0)
        self.reverb_var = tk.DoubleVar(value=0)
        self.echo_var = tk.DoubleVar(value=0)
        self.add_slider(row, "Pitch", self.pitch_var, -12, 12, 0, " semitones")
        self.add_slider(row, "Distortion", self.dist_var, 0, 30, 1, "")
        self.add_slider(row, "Reverb", self.reverb_var, 0, 1, 2, "")
        self.add_slider(row, "Echo", self.echo_var, 0, 0.6, 3, "")

        toggles = tk.Frame(controls, bg="#1e1b29")
        toggles.pack(fill="x", pady=12)
        self.robot_var = tk.BooleanVar()
        self.radio_var = tk.BooleanVar()
        self.comp_var = tk.BooleanVar()
        for label, var in [("Robot effect", self.robot_var), ("Radio filter", self.radio_var), ("Voice compression", self.comp_var)]:
            tk.Checkbutton(toggles, text=label, variable=var, command=self.update_settings,
                           bg="#1e1b29", fg="white", selectcolor="#393148",
                           activebackground="#1e1b29", activeforeground="white").pack(side="left", padx=(0, 18))

        footer = tk.Frame(self.root, bg="#15131d")
        footer.pack(fill="x", padx=24, pady=(8, 20))
        self.start_btn = tk.Button(footer, text="▶  START VOICE CHANGER", command=self.start,
                                   bg="#8055d6", fg="white", activebackground="#986fe8",
                                   relief="flat", font=("Segoe UI", 11, "bold"), padx=16, pady=11)
        self.start_btn.pack(side="left")
        self.stop_btn = tk.Button(footer, text="■  STOP", command=self.stop,
                                  bg="#383047", fg="white", relief="flat", padx=18, pady=11,
                                  state="disabled")
        self.stop_btn.pack(side="left", padx=8)
        self.status = tk.Label(footer, text="● OFFLINE", bg="#15131d", fg="#aaa3b8", font=("Segoe UI", 10, "bold"))
        self.status.pack(side="right")

        note = tk.Label(self.root, text="For Discord/game chat: route output to a virtual audio cable, then select its playback endpoint as your app's microphone.",
                        bg="#15131d", fg="#aaa3b8", wraplength=700, justify="left", font=("Segoe UI", 8))
        note.pack(anchor="w", padx=24, pady=(0, 12))

    def add_slider(self, parent, label, variable, low, high, col, suffix):
        box = tk.Frame(parent, bg="#1e1b29")
        box.grid(row=0, column=col, padx=7, sticky="nsew")
        tk.Label(box, text=label, bg="#1e1b29", fg="white").pack(anchor="w")
        value = tk.Label(box, text=str(variable.get()), bg="#1e1b29", fg="#c6a7ff")
        value.pack(anchor="w")
        scale = tk.Scale(box, from_=low, to=high, resolution=0.1 if high <= 1 else 1,
                         orient="horizontal", variable=variable, length=145,
                         bg="#1e1b29", fg="white", troughcolor="#49405b",
                         highlightthickness=0, command=lambda v: (value.config(text=f"{v}{suffix}"), self.update_settings()))
        scale.pack()
        parent.columnconfigure(col, weight=1)

    def refresh_devices(self):
        try:
            devices = sd.query_devices()
            self.inputs = [(i, d["name"]) for i, d in enumerate(devices) if d["max_input_channels"] > 0]
            self.outputs = [(i, d["name"]) for i, d in enumerate(devices) if d["max_output_channels"] > 0]
            self.input_box["values"] = [f"{i}: {n}" for i, n in self.inputs]
            self.output_box["values"] = [f"{i}: {n}" for i, n in self.outputs]
            if self.inputs: self.input_box.current(0)
            if self.outputs: self.output_box.current(0)
        except Exception as e:
            messagebox.showerror("Audio devices", str(e))

    def apply_preset(self, _=None):
        preset = PRESETS.get(self.preset_box.get(), {})
        self.pitch_var.set(preset.get("pitch", 0))
        self.dist_var.set(preset.get("distortion", 0))
        self.reverb_var.set(preset.get("reverb", 0))
        self.echo_var.set(preset.get("echo", 0))
        self.robot_var.set(preset.get("robot", False))
        self.radio_var.set(preset.get("radio", False))
        self.comp_var.set(preset.get("compress", False))
        self.update_settings()

    def update_settings(self):
        with self.lock:
            self.settings = {"pitch": self.pitch_var.get(), "distortion": self.dist_var.get(),
                             "reverb": self.reverb_var.get(), "echo": self.echo_var.get(),
                             "robot": self.robot_var.get(), "radio": self.radio_var.get(),
                             "compress": self.comp_var.get()}

    def process(self, audio):
        with self.lock:
            s = dict(self.settings)
        board = []
        if s["pitch"]:
            board.append(PitchShift(semitones=float(s["pitch"])))
        if s["radio"]:
            board.extend([HighpassFilter(cutoff_frequency_hz=500), LowpassFilter(cutoff_frequency_hz=3000)])
        if s["robot"]:
            # Robot-like metallic modulation through distortion and short delay.
            board.extend([Distortion(drive_db=10), Chorus(rate_hz=22, depth=0.35)])
        if s["distortion"]:
            board.append(Distortion(drive_db=float(s["distortion"])))
        if s["compress"]:
            board.append(Compressor(threshold_db=-22, ratio=3))
        if s["reverb"]:
            board.append(Reverb(room_size=float(s["reverb"]), wet_level=float(s["reverb"]) * 0.45))
        if s["echo"]:
            board.append(Delay(delay_seconds=0.22, feedback=float(s["echo"]), mix=float(s["echo"]) * 0.45))
        if board:
            return Pedalboard(board)(audio, SAMPLE_RATE)
        return audio

    def audio_callback(self, indata, outdata, frames, time_info, status):
        if status:
            pass
        try:
            mono = indata.T.copy()
            processed = self.process(mono)
            outdata[:] = processed.T[:, :outdata.shape[1]]
        except Exception:
            outdata[:] = indata

    def start(self):
        if self.running:
            return
        if not self.input_box.get() or not self.output_box.get():
            messagebox.showerror("Audio", "Select an input and output device.")
            return
        in_id = int(self.input_box.get().split(":")[0])
        out_id = int(self.output_box.get().split(":")[0])
        try:
            self.stream = sd.Stream(device=(in_id, out_id), samplerate=SAMPLE_RATE,
                                    blocksize=BLOCK_SIZE, channels=(1, 1),
                                    dtype="float32", callback=self.audio_callback)
            self.stream.start()
            self.running = True
            self.start_btn.config(state="disabled")
            self.stop_btn.config(state="normal")
            self.status.config(text="● LIVE", fg="#67e6a3")
        except Exception as e:
            messagebox.showerror("Could not start audio", str(e))

    def stop(self):
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None
        self.running = False
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.status.config(text="● OFFLINE", fg="#aaa3b8")

    def close(self):
        self.stop()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = FreeVoiceStudio(root)
    root.mainloop()