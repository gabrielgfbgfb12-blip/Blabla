# FreeVoice Studio — compilação na nuvem

Este pacote gera `FreeVoiceStudio.exe` usando GitHub Actions. Não é necessário
instalar Python no computador do usuário: o Python é instalado apenas no runner
Windows temporário do GitHub durante a compilação.

Siga o passo a passo em `LEIA-ME-SEM-PYTHON.txt`.

O executável final é um build independente para Windows x64. O projeto usa
bibliotecas de áudio de código aberto e presets originais; não contém arquivos,
modelos ou vozes proprietárias do Voicemod.
